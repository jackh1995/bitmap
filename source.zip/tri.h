#ifndef _TRI_H_
#define _TRI_H_

#include <iostream>
#include "point.h"
#include "bitmap.h"
#include "base.h"

using namespace std;

class Handle;

class Tri : public Base {
friend Handle;
protected:
    Tri():Base() {}
    Tri(const Point& _base, int _left, int _right, int _height, const RGB& _color): Base(_base, _color), left(_left), right(_right), height(_height) {}
    void operator*= (double scale) {
        left = int( double(left)*scale);
        right = int( double(right)*scale);
        height = int( double(height)*scale);
    }
    void draw(Bitmap& map, int method) const {
        map.drawSolidTriangle(this->ref, left, right, height, this->color, method);
    }
    Base* copy() const {
        Base* p = new Tri(this->ref, left, right, height, this->color);
        return p;
    }

    int left;
    int right;
    int height;
};

#endif // _TRI_H_
