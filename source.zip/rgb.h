
#ifndef _RGB_H_
#define _RGB_H_


class RGB {
public:
    RGB(unsigned char _r=0, unsigned char _g=0, unsigned char _b=0):
	    r(_r), g(_g), b(_b) {}

    RGB(const RGB& c): r(c.r), g(c.g), b(c.b) {}

    RGB operator+ (const RGB& c) const {
        RGB result;
        result.r = r + c.r;
        result.g = g + c.g;
        result.b = b + c.b;
        return result;
    }

    RGB operator- (const RGB& c) const {
        RGB result;
        result.r = r - c.r;
        result.g = g - c.g;
        result.b = b - c.b;
        return result;
    }


    unsigned char r;
    unsigned char g;
    unsigned char b;
};


#endif // _RGB_H_
