
#ifndef _POINT_H_
#define _POINT_H_

class Point {
public:
    Point(int _x=0, int _y=0): x(_x),y(_y) {}
    Point(const Point& p): x(p.x),y(p.y) {}
    Point& operator+=(const Point& p) {
        x += p.x;
        y += p.y;
        return *this;
    }
    Point operator+(const Point& p) const {
        Point result;
        result.x = x + p.x;
        result.y = y + p.y;
        return result;
    }
    int x;
    int y;
};

#endif // _POINT_H_
