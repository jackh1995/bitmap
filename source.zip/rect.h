#ifndef _RECT_H_
#define _RECT_H_

#include <iostream>
#include "point.h"
#include "bitmap.h"
#include "base.h"

using namespace std;

class Handle;

class Rect : public Base {
friend Handle;
protected:
    Rect():Base() {}
    Rect(const Point& _base, int _width, int _height, const RGB& _color): Base(_base, _color), width(_width), height(_height) {}
    void operator*= (double scale) {
        width = int( double(width)*scale);
        height = int( double(height)*scale);
    }
    void draw(Bitmap& map, int method) const {
        map.drawSolidRect(this->ref, width, height, this->color, method);
    }
    Base* copy() const {
        Base* p = new Rect(this->ref, width, height, this->color);
        return p;
    }

    int width;
    int height;
};

#endif // _RECT_H_
