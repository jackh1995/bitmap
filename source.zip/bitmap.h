
#ifndef _BITMAP_H_
#define _BITMAP_H_

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include "point.h"
#include "rgb.h"

class Bitmap {
public:
    Bitmap(int _xSize, int _ySize) {
        xSize = _xSize;
        ySize = _ySize;
        image = (unsigned char *)calloc(3, (size_t) xSize * ySize);
    }

    ~Bitmap() {
        free(image);
    }

    void setPixel(const Point& p, const RGB& c, int method) {
        setPixel(p.x, p.y, c, method);
    }

    void setPixel(int x, int y, const RGB& c, int method) {
        unsigned char r, g, b;

        x += xSize / 2;
        y += ySize / 2;

        if (x<0) return;
        if (y<0) return;
        if (x>xSize) return;
        if (y>ySize) return;

        int offset = (y * xSize + x) * 3;
        b = image[offset];
        g = image[offset+1];
        r = image[offset+2];
        if (method < 0) {
            b = (b >= c.b)? (unsigned char)(b-c.b): '\0';
            g = (g >= c.g)? (unsigned char)(g-c.g): '\0';
            r = (r >= c.r)? (unsigned char)(r-c.r): '\0';
        }
        else if (method > 0) {
            b = (b <= 255-c.b)? (unsigned char)(b+c.b): (unsigned char)(255);
            g = (g <= 255-c.g)? (unsigned char)(g+c.g): (unsigned char)(255);
            r = (r <= 255-c.r)? (unsigned char)(r+c.r): (unsigned char)(255);
        }
        else {
            b = c.b;
            g = c.g;
            r = c.r;
        }
        image[offset]  = b;
        image[offset+1]  = g;
        image[offset+2]  = r;

    }

    void drawSolidTriangle(const Point& ref, int left, int right, int height, const RGB& c, int m) {
        Point p0 = ref + Point(-left, 0);
        Point p1 = ref + Point(0, height);
        Point p2 = ref + Point(right, 0);
        drawSolidTriangle(p0, p1, p2, c, m);
    }

    void drawSolidTriangle(const Point& p0, const Point& p1, const Point& p2, const RGB& c, int m) {
        drawSolidTriangle(p0.x, p0.y, p1.x, p1.y, p2.x, p2.y, c, m);
    }

    void drawSolidRect(const Point& base, int width, int height, const RGB& c, int m) {
        for (int x=base.x; x<base.x+width; ++x)
            for (int y=base.y; y<base.y+height; ++y)
                setPixel(x, y, c, m);
    }

    void drawSolidCircle(const Point& center, int radius, const RGB& c, int m) {
        int r2 = radius * radius;
        for (int x=-radius; x<=radius; ++x)
            for (int y=-radius; y<=radius; ++y)
                if (x*x+y*y <= r2)
                    setPixel(center.x+x, center.y+y, c, m);

    }

    void drawSolidTriangle(double x0, double y0, double x1, double y1, double x2, double y2, const RGB& c, int m) {

        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
        }
        if (y2 < y1) {
            swap (y1, y2);
            swap (x1, x2);
        }
        if (y2 < y0) {
            swap (y0, y2);
            swap (x0, x2);
        }
        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
        }

        double xMax = -xSize;
        double xMin = xSize;

        if (xMax < x0) xMax = x0;
        if (xMax < x1) xMax = x1;
        if (xMax < x2) xMax = x2;

        if (xMin > x0) xMin = x0;
        if (xMin > x1) xMin = x1;
        if (xMin > x2) xMin = x2;

        double dx0 = x1 - x0;
        double dy0 = y1 - y0;
        double dx1 = x2 - x1;
        double dy1 = y2 - y1;
        double dx2 = x0 - x2;
        double dy2 = y0 - y2;

        double d0 = (fabs(dy0) > 1e-4)? dx0/dy0 : 0.0;
        double d1 = (fabs(dy1) > 1e-4)? dx1/dy1 : 0.0;
        double d2 = (fabs(dy2) > 1e-4)? dx2/dy2 : 0.0;

        double sx, ex;
        for (int i = (int)(y0+0.5); i < (int)(y1+0.5); ++i) {
            double id = i;
            if (id < y0) id = y0;
            if (id > y1) id = y1;

            sx = x0 + ((id-y0) * d2);
            ex = x0 + ((id-y0) * d0);

            if (sx > ex)
                swap(sx,ex);

            if (sx < xMin) sx = xMin;
            if (ex > xMax) ex = xMax;

            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j)
                setPixel(j,i,c,m);
        }

        for (int i = (int)(y1+0.5); i <= (int)(y2+0.5); ++i) {
            double id = i;
            if (id < y1) id = y1;
            if (id > y2) id = y2;

            sx = x0 + ((id-y0) * d2);
            ex = x1 + ((id-y1) * d1);
            if (sx > ex)
                swap(sx,ex);
            if (sx < xMin) sx = xMin;
            if (ex > xMax) ex = xMax;
            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j)
                setPixel(j,i,c,m);
        }

    }



protected:
    int xSize;
    int ySize;
    unsigned char *image;


public:
    void clear() {
        memset(image, '\0', 3*xSize*ySize);
    }
    int save(const char* filename) const {
        unsigned char header[54] = {
            0x42, 0x4d, 0, 0, 0, 0, 0, 0, 0, 0,
            54, 0, 0, 0, 40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 24, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, 0, 0, 0
        };

        long file_size = (long)xSize * (long)ySize * 3 + 54;
        header[2] = (unsigned char)(file_size &0x000000ff);
        header[3] = (file_size >> 8) & 0x000000ff;
        header[4] = (file_size >> 16) & 0x000000ff;
        header[5] = (file_size >> 24) & 0x000000ff;

        long width = xSize;
        header[18] = width & 0x000000ff;
        header[19] = (width >> 8) &0x000000ff;
        header[20] = (width >> 16) &0x000000ff;
        header[21] = (width >> 24) &0x000000ff;

        long height = ySize;
        header[22] = height &0x000000ff;
        header[23] = (height >> 8) &0x000000ff;
        header[24] = (height >> 16) &0x000000ff;
        header[25] = (height >> 24) &0x000000ff;

        FILE *fp;
        if (!(fp = fopen(filename, "wb")))
            return -1;

        fwrite(header, sizeof(unsigned char), 54, fp);
        fwrite(image, sizeof(unsigned char), (size_t)(long)xSize * ySize * 3, fp);

        fclose(fp);
        return 0;
    }

private:
    template <class T>
    void swap(T& a, T& b) {
        T temp = a;
        a = b;
        b = temp;
    }

};

#endif // _BITMAP_H_ 
