#ifndef _HANDLE_H_
#define _HANDLE_H_

#include <iostream>
#include "point.h"
#include "bitmap.h"
#include "base.h"
#include "circle.h"
#include "rect.h"
#include "tri.h"

using namespace std;

class Handle {
public:
    Handle(): p(NULL) {}
    Handle(const Handle& h) {
        p = h.p;
    }
    Handle(const Point& center, int radius, const RGB& color) {
        p = new Circle(center, radius, color);
    }
    Handle(const Point& center, int width, int height, const RGB& color) {
        p = new Rect(center, width, height, color);
    }
    Handle(const Point& center, int left, int right, int height, const RGB& color) {
        p = new Tri(center, left, right, height, color);
    }
    ~Handle() {
        if (p!=NULL && --(p->count) == 0)
            delete p;
    }

public:
    Handle& operator= (const Handle& h) {
        if (p!=NULL && --(p->count) == 0)
            delete p;
        p = h.p;
        ++(p->count);
        return *this;
    }
    Handle& operator+= (const Point& pp) {
        if (p->count == 1)
           (*p) += pp;
        else {
           --(p->count);
           p = p->copy();
           (*p) += pp; 
        }
        return *this;
    }
    Handle& operator*= (double scale) {
        if (p->count == 1)
            (*p) *= scale;
        else {
            --(p->count);
            p = p->copy();
            (*p) *= scale;
        }
        return *this;
    }
    Handle operator* (double scale) {
        Base *np = p->copy();
        (*np) *= scale;
        return Handle(np);
    }
    Handle operator+ (const Point& pp) {
        Base *np = p->copy();
        (*np) += pp;
        return Handle(np);
    }
    void draw (Bitmap& map, int method) const {
        p->draw(map, method);
    }
    void setColor (const RGB& c) {
        if (p->count == 1)
            p->setColor(c);
        else {
            --(p->count);
            p = p->copy();
            p->setColor(c);
        }
    }
private:
    Handle(Base *_p): p(_p) {}
    Base *p;
};

#endif // _HANDLE_H_
