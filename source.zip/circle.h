#ifndef _CIRCLE_H_
#define _CIRCLE_H_

#include <iostream>
#include "point.h"
#include "bitmap.h"
#include "base.h"

using namespace std;

class Handle;

class Circle : public Base {
friend Handle;
protected:
    Circle():Base() {}
    Circle(const Point& _center, int _radius, const RGB& _color): Base(_center, _color), radius(_radius) {}
    void operator*= (double scale) {
        radius = int( double(radius) * scale);
    }
    void draw(Bitmap& map, int method) const {
        map.drawSolidCircle(this->ref, radius, this->color, method);
    }
    Base* copy() const {
        Base* p = new Circle(this->ref, radius, this->color);
        return p;
    }
    int radius;
};

#endif // _CIRCLE_H_

